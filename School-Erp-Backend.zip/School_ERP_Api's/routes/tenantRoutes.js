const express = require('express');
const router = express.Router();
const tenantController = require('../controllers/tenantController');

router.post('/register', tenantController.registerTenant);
router.get('/list', tenantController.getTenants);
router.put('/:id/suspend', tenantController.suspendTenant);

module.exports = router;
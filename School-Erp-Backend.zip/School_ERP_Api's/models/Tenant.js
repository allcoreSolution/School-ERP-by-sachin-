const mongoose = require('mongoose');

const tenantSchema = new mongoose.Schema({
  schoolName: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String },
  subdomain: { type: String, unique: true },
  plan: { type: String, enum: ['Trial', 'Growth', 'Enterprise'], default: 'Trial' },
  status: { type: String, enum: ['Active', 'Inactive', 'Suspended'], default: 'Active' },
  validUntil: { type: Date },
}, { timestamps: true });

module.exports = mongoose.model('Tenant', tenantSchema);
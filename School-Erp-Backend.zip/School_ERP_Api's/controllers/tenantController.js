const Tenant = require('../models/Tenant');

exports.registerTenant = async (req, res) => {
  try {
    const tenant = new Tenant(req.body);
    await tenant.save();
    res.status(201).json({ success: true, data: tenant });
  } catch (error) { res.status(400).json({ success: false, message: error.message }); }
};

exports.getTenants = async (req, res) => {
  try {
    const tenants = await Tenant.find();
    res.status(200).json({ success: true, data: tenants });
  } catch (error) { res.status(400).json({ success: false, message: error.message }); }
};

exports.suspendTenant = async (req, res) => {
  try {
    const tenant = await Tenant.findByIdAndUpdate(req.params.id, { status: 'Suspended' }, { new: true });
    res.status(200).json({ success: true, data: tenant });
  } catch (error) { res.status(400).json({ success: false, message: error.message }); }
};